const menuBtn = document.querySelector('.menubtn');
const closeBtn = document.querySelector('.closebtn');
const navList = document.querySelector('.nav_list');

menuBtn.addEventListener('click', () => {
    navList.style.transform= 'translateX(0)';
});

closeBtn.addEventListener('click', () => {
    navList.style.transform = 'translateX(-100%)';
});


//Openin and Closin' Search 🔎 
const searchBtn = document.querySelector('.search_button');
const searchInput = document.querySelector('.search_input');
let isOpen = false;

searchBtn.addEventListener('click', () => {
  if (isOpen) {
    searchInput.style.transform = 'translateX(0)';
  } else {
    searchInput.style.transform = 'translateX(130%)';
  }
  isOpen = !isOpen;
});



//#Dropdown Menu

document.addEventListener('DOMContentLoaded', () => {
    const menuItems = document.querySelectorAll('ul > li > a');
    let openDropdown = null;

    menuItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();

            const dropdown = item.nextElementSibling;

            if (dropdown.classList.contains('open')) {
                dropdown.classList.remove('open');
                openDropdown = null;
            } else {
                if (openDropdown) {
                    openDropdown.classList.remove('open');
                }
                dropdown.classList.add('open');
                openDropdown = dropdown;
            }
        });
    });

    document.addEventListener('click', (e) => {
        if (!e.target.closest('ul > li')) {
            if (openDropdown) {
                openDropdown.classList.remove('open');
                openDropdown = null;
            }
        }
    });
});





document.addEventListener('DOMContentLoaded', function () {
    var swiper = new Swiper('.swiper-container', {
      loop: true,
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
      autoplay: {
        delay: 5000,
        disableOnInteraction: false,
      },
      effect: 'slide',
    });
  });